# Izvještaj laboratorijskih vježbi 2

29.10.2021.

## UVOD

U sklopu vježbe student će riješiti odgovarajući *crypto* izazov, odnosno dešifrirati odgovarajući *ciphertext* u kontekstu simetrične kriptografije. Izazov počiva na činjenici da student nema pristup enkripcijskom ključu.

Za pripremu *crypto* izazova, odnosno enkripciju korištena je Python biblioteka [**`cryptography`**](https://cryptography.io/en/latest/). *Plaintext* koji student treba otkriti enkriptiran je korištenjem *high-level* sustava za simetričnu enkripciju iz navedene biblioteke - [Fernet](https://cryptography.io/en/latest/fernet/).

**Stvaramo virtualno okruzenje pythona**

```python
python -m venv mbaric
```

**Instaliramo library `cryptography`**

```python
pip install cryptography
```

**Počinjemo sa generiranjem ključa koji pridružujemo varijabli key**

```python
from cryptography.fernet import Fernet

PLAINTEXT = b"Hello world"

# generiramo enkripcijski ključ
key = Fernet.generate_key()

# kreiramo instancu Fernet klase
fernet = Fernet(key=key)

# enkriptiramo vrijednost variable PLAINTEXT
ciphertext = fernet.encrypt(PLAINTEXT)

# dekriptiramo ciphertext
deciphertext = fernet.decrypt(ciphertext)

print(f"{ciphertext}\n : \n{deciphertext}")
```

Metodom hashiranja, pronalazimo hash stringa marko_baric.

Nakon toga unutar foldera pronalazimo file kojem ime odgovara tom hashu.

```python
from cryptography.hazmat.primitives import hashes

def hash(input):
    if not isinstance(input, bytes):
        input = input.encode()

    digest = hashes.Hash(hashes.SHA256())
    digest.update(input)
    hash = digest.finalize()

    return hash.hex()

filename = hash('prezime_ime') + ".encrypted"

if __name__ == "__main__":
    print(hash("baric_marko"))
```

Nakon toga brute forceamo enkripcijski ključ maksimalne entropije od 22 bita.

**Cijeli kod :**

```python
import base64
from cryptography.hazmat.primitives import hashes
from cryptography.fernet import Fernet

def test_png(header):
    if header.startswith(b"\211PNG\r\n\032\n"):
        return True

def hash(input):
    if not isinstance(input, bytes):
        input = input.encode()

    digest = hashes.Hash(hashes.SHA256())
    digest.update(input)
    hash = digest.finalize()

    return hash.hex()

def brute_force():
    #reading from a file
    filename="86d6f950c23ebe34f81c3896ba63446a292fe506a2e682ba88ab9ca72446adb1.encrypted"
    with open(filename, "rb") as file:
        ciphertext = file.read()
    

    ctr = 0
    while True:
        key_bytes = ctr.to_bytes(32, "big")
        key = base64.urlsafe_b64encode(key_bytes)
        if not (ctr + 1) % 1000:
            print(f"[*] Keys tested: {ctr + 1:,}",end="\r")
        

        # Now initialize the Fernet system with the given key
        # and try to decrypt your challenge.
        # Think, how do you know that the key tested is the correct key
        # (i.e., how do you break out of this infinite loop)?
        try:
            plaintext = Fernet(key).decrypt(ciphertext)
            header=plaintext[:32]

            if test_png(header):
                print(f"[+] Key found : {key}")
                # Writing to a file
                with open("BINGO.png", "wb") as file:
                    file.write(plaintext)
                break
        except Exception:
            pass

        ctr += 1    

if __name__=="__main__":
    brute_force()
```