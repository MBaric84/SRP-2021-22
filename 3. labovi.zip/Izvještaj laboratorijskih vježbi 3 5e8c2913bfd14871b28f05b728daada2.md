# Izvještaj laboratorijskih vježbi 3

8.11.2021.

## **Zadatak 1**

Kreirati tekstualnu datoteku zaštićenog integriteta pomoću HMAC mehanizma i Python biblioteke `cryptography`.

## **Rješenje**

1. Kreiramo file sa porukom koju treba zaštitit. Pročitamo poruku iz filea te je ispisujemo u standardni izlaz.

```python
from cryptography.hazmat.primitives import hashes

def main():
    with open("./message.txt", "rb") as file:
        content = file.read()
        print(content)

if __name__ == "__main__":
    main()
```

1. Kreiramo funkciju za izračun MAC koda. Potrebno je prethodno definirati ključ kojeg koristimo.

```python
from cryptography.hazmat.primitives import hashes, hmac

def generate_MAC(key, message):
    if not isinstance(message, bytes):
        message = message.encode()

    h = hmac.HMAC(key, hashes.SHA256())
    h.update(message)
    signature = h.finalize()
    return signature
```

1. Modificiramo `main` funkciju. Kreiramo MAC kod pomoću prethodno definirane funkcije.

```python
def main():
    secret = b"My super secret"

    with open("./message.txt", "rb") as file:
        content = file.read()

    mac = generate_MAC(secret, content)
    print(mac.hex())
```

1. Zapisujemo generirani MAC u novi file `message.sig`

```python
with open("./message.sig", "wb") as file:
        file.write(mac)
```

1. Kreiramo funkciju za validaciju MAC koda

```python
def is_mac_valid(key, message, mac):
    if not isinstance(message, bytes):
        message = message.encode()

    h = hmac.HMAC(key, hashes.SHA256())
    h.update(message)
    try:
        h.verify(mac)
    except InvalidSignature:
        return False
    else:
        return True
```

1. U funkciju main dodajemo kod za validaciju MACa

```python
with open("./message.sig", "rb") as file:
        mac = file.read()

    if is_mac_valid(secret, content, mac):
        print("MAC je validan")
    else:
        print("MAC nije validan")
```

## **Zadatak 2**

Downloadamo folder sa MAC challengeovima. U njemu se nalazi 10 teksutalnih fileova sa "nalozima za kupnju dionica". Svaki file ima kreirani MAC. Prilikom slanja poruka netko je narušio njihovu sigurnost. Cilj je odrediti ispravnu sekvenciju transakcija autenticnih poruka.

Ključ korišten pri kreiranju MACova napravljen je na idući način.

`key = "<prezime_ime>".encode()t`

## **Rješenje**

```python
from cryptography.hazmat.primitives import hashes, hmac
from cryptography.hazmat.primitives import hashes, hmac
from cryptography.exceptions import InvalidSignature

def verify_MAC(key, signature, message):
    if not isinstance(message, bytes):
        message = message.encode()

    h = hmac.HMAC(key, hashes.SHA256())
    h.update(message)
    try:
        h.verify(signature)
    except InvalidSignature:
        return False
    else:
        return True

def generate_MAC(key, message):
    if not isinstance(message, bytes):
        message = message.encode()

    h = hmac.HMAC(key, hashes.SHA256())
    h.update(message)
    signature = h.finalize()
    return signature

if __name__=="__main__":
    key = "baric_marko".encode()

for ctr in range(1, 11):
    msg_filename = f"order_{ctr}.txt"
    with open(msg_filename,"rb") as file:
        content=file.read()
    sig_filename = f"order_{ctr}.sig"
    with open(sig_filename,"rb") as file:
        mac=file.read()
    
    is_authentic=verify_MAC(key,mac,content)

    print(f'Message {key.decode():>45} {"OK" if is_authentic else "NOK":<6}')
```